<?php
/**
 * Shoutbox Plugin for MyBB
 * Copyright � 2007 MyBB Mods
 *
 * By: Musicalmidget
 * Website: http://mods.mybboard.net/
 */

/* YOU MAY TRANSLATE THIS FILE FOR YOUR OWN PERSONAL USE,
 * AND DISTRIBUTE IT AS YOU WISH.  HOWEVER, YOU MAY NOT
 * DISTRIBUTE ANY FILES FROM THIS PLUGIN OTHER THAN TRANSLATED
 * LANGUAGE FILES WITHOUT THE PRIOR CONSENT OF THE AUTHOR.
 * SEE THE INCLUDED README.TXT FOR FURTHER DETAILS.
 */

$l['shoutbox'] = 'Shoutbox';
$l['shout_refresh'] = 'Shout / Refresh';
$l['edit'] = 'Edit';
$l['enable'] = 'Enable';
$l['disable'] = 'Disable';
$l['edit_shout'] = 'Edit Shout';
$l['delete_shout'] = 'Delete Shout';

$l['shout_hover'] = "Posted: {1} {2}{3}";
$l['shout_hover_ip'] = ', IP Address: {1}';
$l['auto_refresh'] = '{1} Auto Refresh';

$l['confirm_shout_delete'] = 'Are you sure you would like to delete this shout?';

$l['error_no_permission'] = 'You do not have permission to access the shoutbox.';
$l['error_no_shout'] = 'You do not have permission to add shouts to the shoutbox.';
$l['error_no_shouts'] = 'There are currently no shouts to display.';
$l['error_flood'] = 'You have reached the limit for maximum consecutive shouts.  Please wait for another user to shout before attempting to shout again.<br /><a href="{1}">Return to shoutbox</a>';
$l['error_shout_too_long'] = 'Your shout is too long.  The maximum shout length is {1} characters.<br /><a href="{2}">Return to shoutbox</a>';
$l['error_shout_too_short'] = 'Your shout is too short.  The minimum shout length is {1} characters.<br /><a href="{2}">Return to shoutbox</a>';
$l['error_invalid_shout'] = 'Invalid shout.';

$l['redirect_shout_edited'] = 'The shout has been edited successfully.<br />You will now be returned to the shoutbox.';
$l['redirect_shout_deleted'] = 'The shout has been deleted successfully.<br />You will now be returned to the shoutbox.';
?>